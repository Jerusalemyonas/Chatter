import express, { Request, Response } from "express";
import http from "http";
import { Server } from "socket.io";
import cors from "cors";
import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";
import dotenv from "dotenv";

dotenv.config();

const prisma = new PrismaClient();
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});

app.use(cors());
app.use(express.json());

// Global Map to store userId -> socketId
const userSockets = new Map<number, string>();

// --- REST API ---

// 1. Register User
app.post(
  "/api/auth/register",
  async (req: Request, res: Response): Promise<void> => {
    const { username, password } = req.body;
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const avatarUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`;
      const user = await prisma.user.create({
        data: { username, password: hashedPassword, avatarUrl },
      });
      res.json({
        id: user.id,
        username: user.username,
        avatarUrl: user.avatarUrl,
      });
    } catch (error) {
      res.status(400).json({ error: "Username already exists" });
    }
  },
);

// 2. Login User
app.post(
  "/api/auth/login",
  async (req: Request, res: Response): Promise<void> => {
    const { username, password } = req.body;
    const user = await prisma.user.findUnique({ where: { username } });
    if (!user || !(await bcrypt.compare(password, user.password))) {
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }
    res.json({
      id: user.id,
      username: user.username,
      avatarUrl: user.avatarUrl,
    });
  },
);

// 3. Get All Users (Sidebar)
app.get("/api/users", async (req: Request, res: Response): Promise<void> => {
  const { currentUserId } = req.query;
  const users = await prisma.user.findMany({
    where: {
      NOT: { id: Number(currentUserId) },
    },
    select: { id: true, username: true, avatarUrl: true },
  });
  res.json(users);
});

// 4. Delete User (To remove imaginary users)
app.delete(
  "/api/users/:id",
  async (req: Request, res: Response): Promise<void> => {
    const { id } = req.params;
    try {
      // Delete messages first to maintain integrity
      await prisma.message.deleteMany({
        where: {
          OR: [{ senderId: Number(id) }, { receiverId: Number(id) }],
        },
      });
      await prisma.user.delete({
        where: { id: Number(id) },
      });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete user" });
    }
  },
);

// 5. Get Message History
app.get(
  "/api/messages/:contactId",
  async (req: Request, res: Response): Promise<void> => {
    const { contactId } = req.params;
    const { currentUserId } = req.query;
    const messages = await prisma.message.findMany({
      where: {
        OR: [
          { senderId: Number(currentUserId), receiverId: Number(contactId) },
          { senderId: Number(contactId), receiverId: Number(currentUserId) },
        ],
      },
      orderBy: { createdAt: "asc" },
    });
    res.json(messages);
  },
);

// 6. Edit Message
app.put(
  "/api/messages/:id",
  async (req: Request, res: Response): Promise<void> => {
    const { id } = req.params;
    const { content } = req.body;
    try {
      const message = await prisma.message.update({
        where: { id: Number(id) },
        data: { content },
      });
      res.json(message);
    } catch (error) {
      res.status(500).json({ error: "Failed to update message" });
    }
  },
);

// --- Socket.io ---

io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.on("add_user", (userId: number) => {
    userSockets.set(userId, socket.id);
    console.log(`User ${userId} associated with socket ${socket.id}`);
  });

  socket.on(
    "send_msg",
    async (payload: {
      senderId: number;
      receiverId: number;
      content: string;
    }) => {
      const { senderId, receiverId, content } = payload;

      try {
        const message = await prisma.message.create({
          data: { senderId, receiverId, content },
        });

        const receiverSocketId = userSockets.get(receiverId);
        if (receiverSocketId) {
          io.to(receiverSocketId).emit("msg_receive", message);
        }
        socket.emit("msg_sent", message);
      } catch (error) {
        console.error("Error saving message:", error);
      }
    },
  );

  socket.on(
    "edit_msg",
    async (payload: { id: number; content: string; receiverId: number }) => {
      const { id, content, receiverId } = payload;
      try {
        const message = await prisma.message.update({
          where: { id },
          data: { content },
        });
        const receiverSocketId = userSockets.get(receiverId);
        if (receiverSocketId) {
          io.to(receiverSocketId).emit("msg_edited", message);
        }
        socket.emit("msg_edited_self", message);
      } catch (error) {
        console.error("Error editing message:", error);
      }
    },
  );

  socket.on("typing", (payload: { senderId: number; receiverId: number }) => {
    const receiverSocketId = userSockets.get(payload.receiverId);
    if (receiverSocketId) {
      io.to(receiverSocketId).emit("typing", { senderId: payload.senderId });
    }
  });

  socket.on(
    "stop_typing",
    (payload: { senderId: number; receiverId: number }) => {
      const receiverSocketId = userSockets.get(payload.receiverId);
      if (receiverSocketId) {
        io.to(receiverSocketId).emit("stop_typing", {
          senderId: payload.senderId,
        });
      }
    },
  );

  socket.on(
    "read_msg",
    async (payload: { readerId: number; senderId: number }) => {
      const { readerId, senderId } = payload;
      try {
        await prisma.message.updateMany({
          where: { senderId, receiverId: readerId, isRead: false },
          data: { isRead: true },
        });
        const senderSocketId = userSockets.get(senderId);
        if (senderSocketId) {
          io.to(senderSocketId).emit("msg_read_update", { readerId });
        }
      } catch (error) {
        console.error("Error updating read status:", error);
      }
    },
  );

  socket.on("disconnect", () => {
    for (const [userId, socketId] of userSockets.entries()) {
      if (socketId === socket.id) {
        userSockets.delete(userId);
        break;
      }
    }
    console.log("User disconnected:", socket.id);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
