import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import {
  Eye,
  EyeOff,
  MessageSquare,
  Lock,
  Zap,
  Smile,
  Github,
  Globe,
  Monitor,
} from "lucide-react";

const Login: React.FC = () => {
  const [isRegister, setIsRegister] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    const endpoint = isRegister ? "register" : "login";
    try {
      const response = await axios.post(
        `http://localhost:3000/api/auth/${endpoint}`,
        { username, password },
      );
      login(response.data);
      navigate("/chat");
    } catch (err: any) {
      setError(err.response?.data?.error || "Invalid username or password");
    } finally {
      setLoading(false);
    }
  };

  const features = [
    {
      icon: <Lock className="w-5 h-5 text-blue-400" />,
      title: "AES-256 Encryption",
      desc: "Client-side symmetric encryption ensures your data is gibberish to the server.",
    },
    {
      icon: <Zap className="w-5 h-5 text-yellow-400" />,
      title: "Real-time WebSockets",
      desc: "Instant message delivery with zero lag using Socket.io integration.",
    },
    {
      icon: <Smile className="w-5 h-5 text-pink-400" />,
      title: "Emojis and message editing",
      desc: "Send animated emojis to express your feelings and edit your messages after sending them.",
    },
    {
      icon: <Monitor className="w-5 h-5 text-green-400" />,
      title: "Responsive UI",
      desc: "A premium glassmorphic interface designed for desktop and mobile.",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#080b12] text-white selection:bg-primary/30 overflow-x-hidden">
      {/* Left Side: Hero Section */}
      <div className="flex-1 relative flex flex-col justify-center p-6 sm:p-10 md:p-16 overflow-hidden bg-gradient-to-br from-[#0d6cf2]/10 via-transparent to-purple-500/5 min-h-[50vh] md:min-h-screen">
        {/* Decorative Background Elements */}
        <div className="absolute top-[-10%] left-[-10%] w-48 sm:w-72 h-48 sm:h-72 bg-primary/20 rounded-full blur-[80px] sm:blur-[120px] animate-pulse"></div>
        <div className="absolute bottom-[10%] right-[10%] w-64 sm:w-96 h-64 sm:h-96 bg-purple-600/10 rounded-full blur-[100px] sm:blur-[140px]"></div>
        <div
          className="absolute inset-0 z-0 opacity-[0.05]"
          style={{
            backgroundImage: "radial-gradient(#ffffff 1px, transparent 1px)",
            backgroundSize: "40px 40px",
          }}
        ></div>

        <div className="relative z-10 max-w-2xl mx-auto md:mx-0">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-[10px] sm:text-xs font-bold tracking-widest uppercase mb-6 animate-in slide-in-from-left duration-700">
            <Globe className="w-3 h-3" />
            Web Programming Project
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-7xl font-extrabold leading-tight mb-4 animate-in slide-in-from-left duration-700 delay-100">
            Real-Time <br className="hidden sm:block" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-400">
              Messaging
            </span>{" "}
            App
          </h1>

          <p className="text-lg sm:text-xl text-slate-400 mb-8 md:mb-12 max-w-lg animate-in slide-in-from-left duration-700 delay-200">
            A high-performance chatting system implemented with React,
            Socket.io, and Prisma.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 md:gap-8 mb-8 md:mb-16 animate-in slide-in-from-bottom duration-1000 delay-300">
            {features.map((f, i) => (
              <div key={i} className="flex gap-4 group cursor-default">
                <div className="flex-shrink-0 w-10 h-10 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-primary/20 group-hover:border-primary/30 transition-all duration-300">
                  {f.icon}
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-slate-200 mb-1">
                    {f.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
                    {f.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-8 border-t border-white/10 flex items-center justify-between animate-in fade-in duration-1000 delay-500">
            <div className="flex items-center gap-4">
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-gradient-to-tr from-primary to-blue-400 flex items-center justify-center font-bold italic shadow-lg shadow-primary/20 text-sm">
                JL
              </div>
              <div>
                <p className="text-[10px] text-slate-500 uppercase font-bold tracking-tighter">
                  Developed By
                </p>
                <p className="text-sm sm:text-base font-bold text-slate-200">
                  Jerusalem Lema
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <button className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors">
                <Github className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side: Login Form */}
      <div className="w-full md:w-[450px] lg:w-[500px] flex items-center justify-center p-6 sm:p-10 md:p-12 bg-white/[0.02] backdrop-blur-3xl border-t md:border-t-0 md:border-l border-white/5 relative">
        <div className="w-full max-w-sm relative z-10 py-8 md:py-0">
          <div className="text-center mb-8 md:mb-10">
            <div className="w-14 h-14 sm:w-16 sm:h-16 bg-primary rounded-xl sm:rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-2xl shadow-primary/40 rotate-12 transition-transform hover:rotate-0 duration-500">
              <MessageSquare className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold mb-2">
              {isRegister ? "Start Your Journey" : "Welcome Back"}
            </h2>
            <p className="text-slate-500 text-xs sm:text-sm font-medium">
              Please enter your details to continue.
            </p>
          </div>

          {error && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-500 p-3 sm:p-4 rounded-xl mb-6 text-xs sm:text-sm text-center font-medium animate-in zoom-in duration-300">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-5">
            <div>
              <label className="block text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-widest mb-2 px-1">
                Username
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-white/5 border border-white/10 text-white rounded-xl px-4 sm:px-5 py-3 sm:py-4 text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:bg-white/10 transition-all placeholder-slate-600"
                placeholder="ex. jerusalem_admin"
                required
              />
            </div>
            <div>
              <label className="block text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-widest mb-2 px-1">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 text-white rounded-xl px-4 sm:px-5 py-3 sm:py-4 text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:bg-white/10 transition-all pr-12 sm:pr-14 placeholder-slate-600"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 sm:right-5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white transition-colors"
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4 sm:w-5 sm:h-5" />
                  ) : (
                    <Eye className="w-4 h-4 sm:w-5 sm:h-5" />
                  )}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-primary hover:bg-blue-600 text-white font-bold py-3 sm:py-4 rounded-xl shadow-xl shadow-primary/25 transition-all transform hover:scale-[1.02] active:scale-95 mt-6 md:mt-8 flex items-center justify-center gap-2 group text-sm sm:text-base"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              ) : (
                <>
                  {isRegister ? "Create Free Account" : "Login"}
                  <Zap className="w-4 h-4 group-hover:animate-pulse" />
                </>
              )}
            </button>
          </form>

          <p className="text-center text-slate-500 mt-8 md:mt-10 text-xs sm:text-sm font-medium">
            {isRegister
              ? "Already part of the community?"
              : "New to the platform?"}{" "}
            <button
              onClick={() => setIsRegister(!isRegister)}
              className="text-primary font-bold hover:text-blue-400 transition-colors"
            >
              {isRegister ? "Login here" : "Register for free"}
            </button>
          </p>

          <div className="mt-8 md:mt-12 flex items-center justify-center gap-4 sm:gap-6 opacity-30 grayscale hover:grayscale-0 hover:opacity-70 transition-all duration-700">
            <span className="text-[8px] sm:text-[10px] font-black uppercase tracking-[0.2em] sm:tracking-[0.3em]">
              TS
            </span>
            <span className="text-[8px] sm:text-[10px] font-black uppercase tracking-[0.2em] sm:tracking-[0.3em]">
              React
            </span>
            <span className="text-[8px] sm:text-[10px] font-black uppercase tracking-[0.2em] sm:tracking-[0.3em]">
              Prisma
            </span>
            <span className="text-[8px] sm:text-[10px] font-black uppercase tracking-[0.2em] sm:tracking-[0.3em]">
              Docker
            </span>
          </div>
        </div>

        {/* Floating gradient for the right side */}
        <div className="absolute bottom-0 right-0 w-32 h-32 sm:w-48 sm:h-48 bg-primary/20 rounded-full blur-[60px] sm:blur-[100px] pointer-events-none"></div>
      </div>
    </div>
  );
};

export default Login;
