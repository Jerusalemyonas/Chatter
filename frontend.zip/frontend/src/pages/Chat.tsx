import React, { useState, useEffect, useRef, useCallback } from "react";
import { io, Socket } from "socket.io-client";
import axios from "axios";
import { useAuth } from "../context/AuthContext";
import { format } from "date-fns";
import EmojiPicker, { Theme } from "emoji-picker-react";
import { encryptData, decryptData } from "../utils/crypto";
import {
  Search,
  Lock,
  Smile,
  Send,
  CheckCheck,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Menu,
  Trash2,
  Edit2,
  X,
} from "lucide-react";

interface User {
  id: number;
  username: string;
  avatarUrl: string;
}

interface Message {
  id: number;
  content: string;
  senderId: number;
  receiverId: number;
  createdAt: string;
  isRead: boolean;
}

const API_URL = "http://localhost:3000";

// --- Telegram-Style Huge Emoji Logic ---
export const isSingleEmoji = (text: string) => {
  // Regex to detect if the string contains only emojis
  const emojiRegex =
    /^(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff]|[ \t\n\r\f\v])+$/;
  const trimmed = text.trim();
  // Limit to 1 or 2 emojis for the "Huge" effect
  return emojiRegex.test(trimmed) && Array.from(trimmed).length <= 2;
};

const Chat: React.FC = () => {
  const { user, logout } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [editingMessage, setEditingMessage] = useState<Message | null>(null);
  const [editContent, setEditContent] = useState("");
  const [unreadCounts, setUnreadCounts] = useState<Record<number, number>>({});
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);

  const socket = useRef<Socket | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const emojiPickerRef = useRef<HTMLDivElement>(null);
  const profileMenuRef = useRef<HTMLDivElement>(null);

  const selectedUserRef = useRef<User | null>(null);
  const userRef = useRef(user);

  useEffect(() => {
    selectedUserRef.current = selectedUser;
  }, [selectedUser]);
  useEffect(() => {
    userRef.current = user;
  }, [user]);

  useEffect(() => {
    if (!user) return;

    socket.current = io(API_URL);
    socket.current.emit("add_user", user.id);

    socket.current.on("msg_receive", (msg: Message) => {
      const currentSelectedUser = selectedUserRef.current;
      const currentUser = userRef.current;

      if (currentSelectedUser && msg.senderId === currentSelectedUser.id) {
        setMessages((prev) => [...prev, msg]);
        socket.current?.emit("read_msg", {
          readerId: currentUser?.id,
          senderId: currentSelectedUser.id,
        });
      } else {
        setUnreadCounts((prev) => ({
          ...prev,
          [msg.senderId]: (prev[msg.senderId] || 0) + 1,
        }));
      }
    });

    socket.current.on("msg_sent", (msg: Message) => {
      setMessages((prev) => [...prev, msg]);
    });

    socket.current.on("msg_edited", (msg: Message) => {
      setMessages((prev) => prev.map((m) => (m.id === msg.id ? msg : m)));
    });

    socket.current.on("msg_edited_self", (msg: Message) => {
      setMessages((prev) => prev.map((m) => (m.id === msg.id ? msg : m)));
      setEditingMessage(null);
    });

    socket.current.on("typing", (data: { senderId: number }) => {
      const currentSelectedUser = selectedUserRef.current;
      if (currentSelectedUser && data.senderId === currentSelectedUser.id) {
        setIsTyping(true);
      }
    });

    socket.current.on("stop_typing", (data: { senderId: number }) => {
      const currentSelectedUser = selectedUserRef.current;
      if (currentSelectedUser && data.senderId === currentSelectedUser.id) {
        setIsTyping(false);
      }
    });

    socket.current.on("msg_read_update", (data: { readerId: number }) => {
      const currentSelectedUser = selectedUserRef.current;
      const currentUser = userRef.current;
      if (currentSelectedUser && data.readerId === currentSelectedUser.id) {
        setMessages((prev) =>
          prev.map((m) =>
            m.senderId === currentUser?.id ? { ...m, isRead: true } : m,
          ),
        );
      }
    });

    return () => {
      socket.current?.disconnect();
    };
  }, [user]);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await axios.get(
          `${API_URL}/api/users?currentUserId=${user?.id}`,
        );
        setUsers(res.data);
        setFilteredUsers(res.data);
      } catch (err) {
        console.error(err);
      }
    };
    if (user) fetchUsers();
  }, [user]);

  useEffect(() => {
    const res = users.filter((u) =>
      u.username.toLowerCase().includes(searchTerm.toLowerCase()),
    );
    setFilteredUsers(res);
  }, [searchTerm, users]);

  useEffect(() => {
    const fetchMessages = async () => {
      if (!selectedUser) return;
      setLoading(true);
      try {
        const res = await axios.get(
          `${API_URL}/api/messages/${selectedUser.id}?currentUserId=${user?.id}`,
        );
        setMessages(res.data);
        socket.current?.emit("read_msg", {
          readerId: user?.id,
          senderId: selectedUser.id,
        });
        setUnreadCounts((prev) => ({ ...prev, [selectedUser.id]: 0 }));
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchMessages();
    setIsTyping(false);
    setIsMobileMenuOpen(false);
  }, [selectedUser, user]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        emojiPickerRef.current &&
        !emojiPickerRef.current.contains(event.target as Node)
      ) {
        setShowEmojiPicker(false);
      }
      if (
        profileMenuRef.current &&
        !profileMenuRef.current.contains(event.target as Node)
      ) {
        setIsProfileMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSend = useCallback(
    (e?: React.FormEvent) => {
      e?.preventDefault();
      if (!newMessage.trim() || !selectedUser || !user) return;

      const encryptedContent = encryptData(newMessage.trim());
      socket.current?.emit("send_msg", {
        senderId: user.id,
        receiverId: selectedUser.id,
        content: encryptedContent,
      });
      setNewMessage("");
      setShowEmojiPicker(false);
      socket.current?.emit("stop_typing", {
        senderId: user.id,
        receiverId: selectedUser.id,
      });
    },
    [newMessage, selectedUser, user],
  );

  const handleEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMessage || !editContent.trim() || !selectedUser) return;
    const encryptedEdit = encryptData(editContent.trim());
    socket.current?.emit("edit_msg", {
      id: editingMessage.id,
      content: encryptedEdit,
      receiverId: selectedUser.id,
    });
  };

  const deleteUser = async (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if (
      !window.confirm(
        "Are you sure you want to delete this user and all their history?",
      )
    )
      return;
    try {
      await axios.delete(`${API_URL}/api/users/${id}`);
      setUsers(users.filter((u) => u.id !== id));
      if (selectedUser?.id === id) setSelectedUser(null);
    } catch (err) {
      console.error("Failed to delete user", err);
    }
  };

  const handleTyping = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNewMessage(e.target.value);
    if (!selectedUser || !user) return;
    socket.current?.emit("typing", {
      senderId: user.id,
      receiverId: selectedUser.id,
    });
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      socket.current?.emit("stop_typing", {
        senderId: user.id,
        receiverId: selectedUser.id,
      });
    }, 2000);
  };

  return (
    <div className="flex w-full h-screen relative bg-background-light dark:bg-background-dark overflow-hidden">
      <div className="md:hidden absolute top-6 left-4 z-50">
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 bg-primary text-white rounded-lg shadow-lg"
        >
          <Menu className="w-6 h-6" />
        </button>
      </div>

      <aside
        className={`fixed md:relative h-full flex flex-col border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-surface-dark transition-all duration-300 z-40 
          ${isSidebarCollapsed ? "w-20" : "w-80"} 
          ${isMobileMenuOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"}
        `}
      >
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center bg-white dark:bg-surface-dark relative">
          <div
            className={`flex items-center gap-3 cursor-pointer group/profile transition-all ${isSidebarCollapsed ? "hidden" : "flex hover:bg-slate-50 dark:hover:bg-slate-800 p-1.5 rounded-xl"}`}
            onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
            ref={profileMenuRef}
          >
            <div className="relative">
              <img
                alt="Avatar"
                className="w-10 h-10 rounded-full object-cover border-2 border-primary"
                src={user?.avatarUrl}
              />
              <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white dark:border-surface-dark rounded-full"></span>
            </div>
            <div className="min-w-0 text-left">
              <h2 className="font-semibold text-sm truncate">
                {user?.username}
              </h2>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                Online
              </span>
            </div>

            {isProfileMenuOpen && (
              <div className="absolute top-full left-4 mt-2 w-48 bg-white dark:bg-surface-dark rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 z-50 overflow-hidden animate-in fade-in slide-in-from-top-1 duration-200">
                <div className="p-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30">
                  <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
                    Signed in as
                  </p>
                  <p className="text-sm font-bold truncate text-slate-900 dark:text-white">
                    {user?.username}
                  </p>
                </div>
                <button
                  onClick={logout}
                  className="w-full flex items-center gap-3 px-4 py-3 text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors font-medium"
                >
                  <LogOut className="w-4 h-4" /> Logout
                </button>
              </div>
            )}
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
              className="hidden md:block p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500"
            >
              {isSidebarCollapsed ? (
                <ChevronRight className="w-5 h-5" />
              ) : (
                <ChevronLeft className="w-5 h-5" />
              )}
            </button>
            {isSidebarCollapsed && (
              <button
                onClick={logout}
                title="Logout"
                className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500"
              >
                <LogOut className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {!isSidebarCollapsed && (
          <div className="px-4 py-3">
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                <Search className="w-4 h-4" />
              </span>
              <input
                className="w-full bg-slate-100 dark:bg-background-dark text-sm rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary border-none text-slate-700 dark:text-slate-200"
                placeholder="Filter chats..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto">
          <div className="px-2 pb-2 space-y-1">
            {filteredUsers.map((u) => (
              <div
                key={u.id}
                onClick={() => setSelectedUser(u)}
                className={`group flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-colors border-l-4 ${selectedUser?.id === u.id ? "bg-primary/10 dark:bg-primary/20 border-primary" : "hover:bg-slate-100 dark:hover:bg-surface-hover border-transparent"} ${isSidebarCollapsed ? "justify-center" : ""}`}
              >
                <div className="relative flex-shrink-0">
                  <img
                    className="w-12 h-12 rounded-full object-cover"
                    src={u.avatarUrl}
                    alt={u.username}
                  />
                  <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white dark:border-surface-dark rounded-full"></span>
                  {isSidebarCollapsed && unreadCounts[u.id] > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-primary text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white dark:border-surface-dark">
                      {unreadCounts[u.id]}
                    </span>
                  )}
                </div>
                {!isSidebarCollapsed && (
                  <div className="flex-1 min-w-0 flex justify-between items-center">
                    <div className="min-w-0 text-left">
                      <h3 className="font-semibold text-sm truncate text-slate-900 dark:text-white">
                        {u.username}
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        Tap to chat
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {unreadCounts[u.id] > 0 && (
                        <span className="w-5 h-5 bg-primary text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                          {unreadCounts[u.id]}
                        </span>
                      )}
                      <button
                        onClick={(e) => deleteUser(u.id, e)}
                        className="opacity-0 group-hover:opacity-100 p-2 text-slate-400 hover:text-red-500 hover:bg-red-500/10 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </aside>

      <main className="flex-1 flex flex-col relative bg-background-light dark:bg-background-dark">
        <div
          className="absolute inset-0 z-0 opacity-[0.03] pointer-events-none"
          style={{
            backgroundImage: "radial-gradient(#0d6cf2 1px, transparent 1px)",
            backgroundSize: "24px 24px",
          }}
        ></div>

        {selectedUser ? (
          <>
            <header className="h-20 px-6 border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md flex items-center justify-between z-10 sticky top-0">
              <div className="flex items-center gap-4 pl-12 md:pl-0">
                <div className="relative">
                  <img
                    className="w-11 h-11 rounded-full object-cover shadow-sm"
                    src={selectedUser.avatarUrl}
                    alt={selectedUser.username}
                  />
                  <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white dark:border-background-dark rounded-full shadow-sm"></span>
                </div>
                <div className="text-left">
                  <div className="flex items-center gap-2">
                    <h1 className="text-lg font-bold text-slate-900 dark:text-white leading-tight">
                      {selectedUser.username}
                    </h1>
                    <Lock className="w-3.5 h-3.5 text-primary opacity-60" />
                  </div>
                  {isTyping ? (
                    <span className="text-xs text-primary font-medium tracking-wide uppercase animate-pulse">
                      Typing...
                    </span>
                  ) : (
                    <span className="text-xs text-green-500 font-medium">
                      Online
                    </span>
                  )}
                </div>
              </div>
              <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-slate-100 dark:bg-surface-hover rounded-full border border-slate-200 dark:border-slate-700/50">
                <Lock className="w-3 h-3 text-green-500" />
                <span className="text-[10px] font-semibold tracking-wider text-slate-600 dark:text-slate-300 uppercase">
                  End-to-End Encrypted
                </span>
              </div>
            </header>

            <div className="flex-1 overflow-y-auto p-6 space-y-6 scroll-smooth z-0 relative">
              {messages.map((msg) => {
                const decryptedContent = decryptData(msg.content);
                const isBigEmoji = isSingleEmoji(decryptedContent);
                const isHeart =
                  decryptedContent.includes("❤️") ||
                  decryptedContent.includes("♥️");

                if (isBigEmoji) {
                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col gap-1 ${msg.senderId === user?.id ? "items-end ml-auto" : "items-start"} max-w-[85%]`}
                    >
                      <span
                        className={`text-6xl select-none cursor-default ${isHeart ? "animate-heart" : "animate-pop"}`}
                        title="Big Emoji"
                      >
                        {decryptedContent}
                      </span>
                      <div
                        className={`flex items-center gap-1 mt-1 opacity-60 ${msg.senderId === user?.id ? "justify-end" : "justify-start"}`}
                      >
                        <span className="text-[10px]">
                          {format(new Date(msg.createdAt), "h:mm a")}
                        </span>
                        {msg.senderId === user?.id && (
                          <CheckCheck
                            className={`w-3 h-3 ${msg.isRead ? "text-primary" : "text-slate-400"}`}
                          />
                        )}
                      </div>
                    </div>
                  );
                }

                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col gap-1 ${msg.senderId === user?.id ? "items-end ml-auto" : "items-start"} max-w-[85%] md:max-w-2xl group`}
                  >
                    <div className="flex items-center gap-2">
                      {msg.senderId === user?.id && (
                        <button
                          onClick={() => {
                            setEditingMessage(msg);
                            setEditContent(decryptedContent);
                          }}
                          className="opacity-0 group-hover:opacity-100 p-1.5 text-slate-400 hover:text-primary transition-all rounded-lg"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <div
                        className={`p-4 rounded-2xl shadow-sm relative ${msg.senderId === user?.id ? "glass-bubble-outgoing rounded-br-none text-white" : "glass-bubble-incoming rounded-bl-none text-slate-800 dark:text-slate-200"}`}
                      >
                        <p className="text-sm leading-relaxed break-words whitespace-pre-wrap">
                          {decryptedContent}
                        </p>
                        <div
                          className={`flex items-center gap-1 mt-1 opacity-80 ${msg.senderId === user?.id ? "justify-end" : "justify-start"}`}
                        >
                          <span className="text-[10px]">
                            {format(new Date(msg.createdAt), "h:mm a")}
                          </span>
                          {msg.senderId === user?.id && (
                            <CheckCheck
                              className={`w-3 h-3 ${msg.isRead ? "text-blue-200" : "text-slate-300"}`}
                            />
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
              <div ref={scrollRef} />
            </div>

            <footer className="p-4 bg-white dark:bg-background-dark border-t border-slate-200 dark:border-slate-800 z-10 relative">
              {editingMessage && (
                <div className="max-w-4xl mx-auto mb-3 flex items-center justify-between bg-primary/10 p-3 rounded-xl border border-primary/20">
                  <div className="flex items-center gap-3">
                    <Edit2 className="w-4 h-4 text-primary" />
                    <span className="text-sm font-medium">Editing message</span>
                  </div>
                  <button
                    onClick={() => setEditingMessage(null)}
                    className="p-1 hover:bg-primary/20 rounded-full"
                  >
                    <X className="w-4 h-4 text-primary" />
                  </button>
                </div>
              )}
              <form
                onSubmit={editingMessage ? handleEdit : handleSend}
                className="max-w-4xl mx-auto flex items-end gap-2"
              >
                <div className="relative" ref={emojiPickerRef}>
                  <button
                    type="button"
                    onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                    className={`p-2 rounded-full transition-colors ${showEmojiPicker ? "text-primary bg-primary/10" : "text-slate-500 hover:text-primary"}`}
                  >
                    <Smile className="w-6 h-6" />
                  </button>
                  {showEmojiPicker && (
                    <div className="absolute bottom-full left-0 mb-4 z-50">
                      <EmojiPicker
                        theme={Theme.DARK}
                        onEmojiClick={(emojiData) => {
                          const setContent = editingMessage
                            ? setEditContent
                            : setNewMessage;
                          const content = editingMessage
                            ? editContent
                            : newMessage;
                          setContent(content + emojiData.emoji);
                        }}
                      />
                    </div>
                  )}
                </div>
                <div className="flex-1 bg-slate-100 dark:bg-surface-dark rounded-xl p-1 relative border border-transparent focus-within:border-primary">
                  <textarea
                    className="w-full bg-transparent border-none text-slate-800 dark:text-slate-200 text-sm focus:ring-0 resize-none py-3 px-3 min-h-[44px] max-h-32 outline-none"
                    placeholder={
                      editingMessage ? "Edit message..." : "Type a message..."
                    }
                    rows={1}
                    value={editingMessage ? editContent : newMessage}
                    onChange={
                      editingMessage
                        ? (e) => setEditContent(e.target.value)
                        : handleTyping
                    }
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        if (editingMessage) handleEdit(e);
                        else handleSend();
                      }
                      if (e.key === "Escape") setEditingMessage(null);
                    }}
                  />
                </div>
                <button
                  type="submit"
                  className="bg-primary hover:bg-blue-600 text-white p-3 rounded-xl shadow-lg transition-all transform hover:scale-105 active:scale-95"
                >
                  <Send className="w-5 h-5 translate-x-0.5" />
                </button>
              </form>
            </footer>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center p-6 text-center">
            <div className="p-8 glass-panel rounded-2xl max-w-sm">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Send className="w-8 h-8 text-primary" />
              </div>
              <h2 className="text-xl font-bold mb-2 text-white">
                Your Messages
              </h2>
              <p className="text-slate-400">
                Select a contact to start chatting. Your conversations are
                encrypted and secure.
              </p>
            </div>
          </div>
        )}
      </main>
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 md:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
    </div>
  );
};

export default Chat;
