import CryptoJS from "crypto-js";

const SECRET_KEY = "my_super_secret_university_key";

export const encryptData = (text: string): string => {
  return CryptoJS.AES.encrypt(text, SECRET_KEY).toString();
};

export const decryptData = (cipherText: string): string => {
  try {
    const bytes = CryptoJS.AES.decrypt(cipherText, SECRET_KEY);
    const originalText = bytes.toString(CryptoJS.enc.Utf8);
    // If it was encrypted, it will return the text, if it fails or was plain text, it returns original
    return originalText || cipherText;
  } catch (error) {
    return cipherText;
  }
};
